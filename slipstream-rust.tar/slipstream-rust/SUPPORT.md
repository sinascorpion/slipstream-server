# Support

For questions, bug reports, or feature requests:

- Open a GitHub issue with details and reproduction steps.
- For design or usage questions, start a discussion if enabled.

For security issues, see SECURITY.md.
